from django.db import models

# Create your models here.
class BrainStroke(models.Model):
    age=models.CharField(max_length=190)
    gender=models.CharField(max_length=190)
    hypertension=models.CharField(max_length=190)
    heart_disease=models.CharField(max_length=190)
    ever_married=models.CharField(max_length=190)
    work_type=models.CharField(max_length=190)
    residence_type=models.CharField(max_length=190)
    Avg_Gluocose=models.CharField(max_length=190)
    BMI=models.CharField(max_length=190)
    Smoking_Status=models.CharField(max_length=190)
    Stroke_Prediction=models.CharField(max_length=190)